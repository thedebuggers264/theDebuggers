"""
GramCare - Hackathon Starter
A non-diagnostic digital healthcare assistance platform for rural communities.

Run with:  python app.py
Then open: http://127.0.0.1:5000
"""

from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import os

app = Flask(__name__)
DB_PATH = os.path.join(os.path.dirname(__file__), "database.db")


# ---------- DATABASE SETUP ----------

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_name TEXT NOT NULL,
            age INTEGER,
            reason TEXT,
            preferred_date TEXT,
            status TEXT DEFAULT 'Pending'
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            reminder_time TEXT NOT NULL,
            notes TEXT
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS hospitals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT,
            address TEXT,
            phone TEXT,
            lat REAL,
            lng REAL
        )
    """)

    # Seed with real Chennai government healthcare facilities.
    # To use a different city, replace these rows with local facility data.
    cur.execute("SELECT COUNT(*) FROM hospitals")
    if cur.fetchone()[0] == 0:
        sample_hospitals = [
            ("Rajiv Gandhi Government General Hospital", "Government Hospital",
             "Grand Western Trunk Road, Park Town, Chennai", "044-25305000", 13.081417, 80.277194),
            ("Government Kilpauk Medical College Hospital", "Government Hospital",
             "Poonamallee High Road, Kilpauk, Chennai", "044-28364951", 13.077536, 80.242866),
            ("Government Hospital of Thoracic Medicine", "Government Hospital",
             "Grand Southern Trunk Road, Tambaram Sanatorium, Chennai", "108", 12.944440, 80.129170),
            ("Government Urban Primary Health Centre, Thoraipakkam", "PHC",
             "SH 49A, Rajiv Gandhi Salai, Thoraipakkam, Chennai", "108", 12.943000, 80.241000),
        ]
        cur.executemany(
            "INSERT INTO hospitals (name, type, address, phone, lat, lng) VALUES (?, ?, ?, ?, ?, ?)",
            sample_hospitals,
        )

    conn.commit()
    conn.close()


# ---------- SIMPLE RULE-BASED CHATBOT ----------
# NOTE: This is intentionally NOT a diagnostic AI. It matches keywords to
# safe, general guidance and always tells the user to see a professional
# for anything serious. Expand this dictionary with more keywords/answers.

CHATBOT_RESPONSES = {
    "fever": "For mild fever: rest, drink fluids, and monitor temperature. "
              "If fever is high (above 103°F/39.4°C), lasts more than 2 days, "
              "or comes with severe symptoms, please visit a health center immediately.",
    "cold": "For a common cold: rest, warm fluids, and steam inhalation may help. "
            "See a doctor if symptoms worsen or last more than a week.",
    "cough": "Stay hydrated and avoid cold drinks. If coughing lasts more than 2 weeks, "
             "or you notice blood or breathing difficulty, seek medical care right away.",
    "headache": "Rest in a quiet, dark room and stay hydrated. "
                "If the headache is sudden, severe, or with vision issues, seek care immediately.",
    "vaccination": "Vaccination schedules vary by age. Please visit your nearest PHC "
                   "for the official immunization schedule and records.",
    "pregnant": "For pregnancy-related concerns, regular checkups at a PHC or hospital "
                "are important. Please book an appointment for proper care.",
    "emergency": "If this is a medical emergency, please call your local emergency number "
                 "or go to the nearest hospital immediately.",

    # Hindi keywords — expand this set with more common terms as needed.
    "बुखार": "हल्के बुखार के लिए आराम करें और तरल पदार्थ पिएं। "
             "यदि बुखार तेज़ है या 2 दिन से ज़्यादा रहता है, तो कृपया तुरंत स्वास्थ्य केंद्र जाएं।",
    "खांसी": "गर्म तरल पदार्थ पिएं और ठंडी चीज़ों से बचें। "
             "यदि खांसी 2 हफ्तों से ज़्यादा रहे या सांस लेने में तकलीफ हो, तो तुरंत डॉक्टर से मिलें।",
    "सिरदर्द": "शांत, अंधेरे कमरे में आराम करें और पानी पिएं। "
               "यदि सिरदर्द अचानक और गंभीर हो, तो तुरंत चिकित्सा सहायता लें।",

    # Tamil keywords
    "காய்ச்சல்": "லேசான காய்ச்சலுக்கு ஓய்வு எடுத்து நீர் அருந்தவும். "
                 "காய்ச்சல் அதிகமாகவோ 2 நாட்களுக்கு மேல் நீடித்தாலோ, உடனடியாக மருத்துவமனையை அணுகவும்.",
    "இருமல்": "சூடான திரவங்களை அருந்தவும், குளிர்ந்த பானங்களைத் தவிர்க்கவும். "
              "இருமல் 2 வாரங்களுக்கு மேல் நீடித்தால் அல்லது மூச்சுத் திணறல் இருந்தால், உடனே மருத்துவரை அணுகவும்.",
    "தலைவலி": "அமைதியான, இருண்ட அறையில் ஓய்வெடுத்து நீர் அருந்தவும். "
              "திடீர் அல்லது கடுமையான தலைவலி இருந்தால், உடனடியாக மருத்துவ உதவி பெறவும்.",
}

DEFAULT_RESPONSE = (
    "I'm a basic health information assistant and I can't diagnose conditions. "
    "For anything concerning, please book an appointment or contact a healthcare "
    "professional. Try asking about: fever, cold, cough, headache, vaccination, or pregnancy."
)


def get_bot_response(user_message: str) -> str:
    message = user_message.lower()
    for keyword, response in CHATBOT_RESPONSES.items():
        if keyword in message:
            return response
    return DEFAULT_RESPONSE


# ---------- ROUTES ----------

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chatbot", methods=["GET", "POST"])
def chatbot():
    bot_reply = None
    user_message = None
    if request.method == "POST":
        user_message = request.form.get("message", "")
        bot_reply = get_bot_response(user_message)
    return render_template("chatbot.html", user_message=user_message, bot_reply=bot_reply)


@app.route("/api/chat", methods=["POST"])
def api_chat():
    """JSON endpoint so the frontend JS can call the bot without a page reload."""
    data = request.get_json(force=True)
    message = data.get("message", "")
    return jsonify({"reply": get_bot_response(message)})


@app.route("/locator")
def locator():
    conn = get_db()
    hospitals = conn.execute("SELECT * FROM hospitals").fetchall()
    conn.close()
    # The user can type their own area/city — we don't hardcode one location.
    # Falls back to a generic "hospitals near me" search if nothing is entered.
    search_area = request.args.get("area", "").strip()
    return render_template("locator.html", hospitals=hospitals, search_area=search_area)


@app.route("/appointments", methods=["GET", "POST"])
def appointments():
    conn = get_db()
    if request.method == "POST":
        name = request.form.get("patient_name")
        age = request.form.get("age")
        reason = request.form.get("reason")
        date = request.form.get("preferred_date")
        conn.execute(
            "INSERT INTO appointments (patient_name, age, reason, preferred_date) VALUES (?, ?, ?, ?)",
            (name, age, reason, date),
        )
        conn.commit()
        return redirect(url_for("appointments"))

    all_appointments = conn.execute("SELECT * FROM appointments ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("appointments.html", appointments=all_appointments)


@app.route("/appointments/cancel/<int:appointment_id>", methods=["POST"])
def cancel_appointment(appointment_id):
    conn = get_db()
    conn.execute("UPDATE appointments SET status = 'Cancelled' WHERE id = ?", (appointment_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("appointments"))


@app.route("/reminders", methods=["GET", "POST"])
def reminders():
    conn = get_db()
    if request.method == "POST":
        title = request.form.get("title")
        reminder_time = request.form.get("reminder_time")
        notes = request.form.get("notes")
        conn.execute(
            "INSERT INTO reminders (title, reminder_time, notes) VALUES (?, ?, ?)",
            (title, reminder_time, notes),
        )
        conn.commit()
        return redirect(url_for("reminders"))

    all_reminders = conn.execute("SELECT * FROM reminders ORDER BY reminder_time ASC").fetchall()
    conn.close()
    return render_template("reminders.html", reminders=all_reminders)


@app.route("/reminders/delete/<int:reminder_id>", methods=["POST"])
def delete_reminder(reminder_id):
    conn = get_db()
    conn.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("reminders"))


@app.route("/emergency")
def emergency():
    return render_template("emergency.html")


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
