# GramCare — Hackathon Starter

A non-diagnostic healthcare accessibility platform for Problem Statement #2.
Built with Python (Flask) + SQLite + Bootstrap so the whole team can work with
skills you already have.

## What's included (working out of the box)

- **Health Chat** — rule-based Q&A (`/chatbot`), safe for demo, easy to extend, now with
  Hindi and Tamil keyword support alongside English
- **Hospital Locator** — real Chennai government hospitals/PHCs with map (`/locator`) —
  swap in your own city's facilities in `init_db()` in `app.py`
- **Appointments** — request/view/cancel (`/appointments`)
- **Reminders** — medicine/appointment reminders with due-soon and overdue highlighting,
  an in-tab sound + popup alert when a reminder's time arrives (click "Enable alerts" on
  the page), and a "Done" button to clear them (`/reminders`)
- **Emergency page** — tap-to-call contacts (`/emergency`)
- **Multilingual voice input** on the chat page — English, Hindi, or Tamil, selectable
  via dropdown, using the browser's built-in Web Speech API (no extra install, works in Chrome)

## Setup (Windows)

1. Install Python 3.10+ from python.org (check "Add to PATH" during install)
2. Open Command Prompt in this folder
3. Run:
   ```
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
4. Open http://127.0.0.1:5000 in your browser

## Setup (Ubuntu)

1. Open a terminal in this folder
2. Run:
   ```
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python3 app.py
   ```
3. Open http://127.0.0.1:5000 in your browser

The database (`database.db`) is created automatically on first run — no manual
DB setup needed. It's just a file, so it works identically on every machine.

## Working as a team of 3 (all on different OSes)

1. One person creates a GitHub repo and pushes this starter code
2. Everyone else runs `git clone <repo-url>`
3. Each person works on their part (see below), commits, and pushes often —
   pull before you push to avoid conflicts
4. `database.db` should NOT be committed to Git (it's local test data) —
   see `.gitignore` included

Suggested split:
- **Backend/DB person:** extend `app.py` — add real fields, expand the
  `CHATBOT_RESPONSES` dictionary, add patient profile table
- **Frontend person:** style the templates in `templates/`, improve
  `static/css/style.css`, polish mobile responsiveness
- **Integration person:** hospital locator data (`locator.html` /
  the `hospitals` table), appointment ↔ reminder linking, prep the demo

## Project structure

```
rural-health-assistant/
├── app.py                 # Flask app: routes, DB, chatbot logic
├── requirements.txt
├── database.db             # created automatically on first run
├── templates/
│   ├── base.html            # shared layout + navbar
│   ├── index.html           # dashboard
│   ├── chatbot.html
│   ├── locator.html
│   ├── appointments.html
│   ├── reminders.html
│   └── emergency.html
└── static/
    ├── css/style.css
    └── js/chatbot.js        # chat + voice input logic
```

## Easy wins to add if you have extra time

- **Multilingual chatbot:** add a language dropdown, and a second dictionary
  of keyword→response pairs in your local language(s). Even a simple
  `if lang == "te": responses = TELUGU_RESPONSES` swap is enough for a demo.
- **Real hospital data:** replace the 3 sample rows in `init_db()` with
  actual nearby facilities — much stronger for judges than placeholder data.
- **Patient profile page:** one more table (`patients`) + a simple form,
  same pattern as `appointments`.
- **Reminder highlighting:** in `reminders.html`, use JS to highlight/sort
  reminders due within the next 24 hours.

## Reminder for your pitch

Emphasize clearly in your demo: **this tool gives general information and
connects people to care — it does not diagnose.** That framing directly
matches the problem statement's requirement and reassures judges about
safety/ethics, which is often a scoring criterion in health-tech hackathons.

## Being honest about the reminders feature

Reminder alerts (sound + popup) only fire **while the reminders page is open
in the browser** — a website can't wake up on its own and ring like a phone
alarm app. If a judge asks about this, the honest answer is: *"For a true
background alarm — one that rings even with the app closed — we'd need SMS
or push notifications sent from a server, which is a natural next step
beyond this hackathon's scope."* This is a normal, expected limitation for
a browser-based MVP and shows you understand the tradeoff rather than
overclaiming.
