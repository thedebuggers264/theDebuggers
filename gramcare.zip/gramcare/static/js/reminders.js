// ---- Highlighting: runs immediately, no permission needed ----
function updateReminderBadges() {
    document.querySelectorAll(".gc-reminder-item").forEach((item) => {
        const timeStr = item.dataset.time;
        if (!timeStr) return;
        const due = new Date(timeStr);
        const now = new Date();
        const hoursUntil = (due - now) / (1000 * 60 * 60);
        const badge = item.querySelector(".gc-due-badge");

        if (hoursUntil < 0) {
            badge.textContent = "Overdue";
            badge.className = "badge gc-due-badge ms-2 bg-danger";
            badge.style.display = "inline-block";
            item.style.borderLeft = "4px solid var(--gc-clay)";
        } else if (hoursUntil <= 24) {
            badge.textContent = "Due soon";
            badge.className = "badge gc-due-badge ms-2 bg-warning text-dark";
            badge.style.display = "inline-block";
            item.style.borderLeft = "4px solid var(--gc-marigold)";
        }
    });
}
updateReminderBadges();

// ---- Alert sound: a simple beep via Web Audio, no external file needed ----
function playBeep() {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        oscillator.connect(gain);
        gain.connect(ctx.destination);
        oscillator.type = "sine";
        oscillator.frequency.value = 880;
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        oscillator.start();
        oscillator.stop(ctx.currentTime + 0.35);
        // Second beep for attention
        setTimeout(() => {
            const osc2 = ctx.createOscillator();
            const gain2 = ctx.createGain();
            osc2.connect(gain2);
            gain2.connect(ctx.destination);
            osc2.type = "sine";
            osc2.frequency.value = 880;
            gain2.gain.setValueAtTime(0.15, ctx.currentTime);
            osc2.start();
            osc2.stop(ctx.currentTime + 0.35);
        }, 450);
    } catch (e) {
        // Audio not available — the on-page banner still shows.
    }
}

// ---- On-page alert banner ----
const alertBanner = document.getElementById("gcAlertBanner");
const alertText = document.getElementById("gcAlertText");
const alertDismiss = document.getElementById("gcAlertDismiss");

function showAlertBanner(title) {
    if (!alertBanner) return;
    alertText.textContent = "Reminder: " + title;
    alertBanner.style.display = "flex";
}
if (alertDismiss) {
    alertDismiss.addEventListener("click", () => {
        alertBanner.style.display = "none";
    });
}

// ---- Browser notification permission ----
const enableBtn = document.getElementById("gcEnableAlerts");
const alertsStatus = document.getElementById("gcAlertsStatus");
let alertsEnabled = false;

if (enableBtn) {
    enableBtn.addEventListener("click", async () => {
        if ("Notification" in window) {
            const permission = await Notification.requestPermission();
            if (permission === "granted") {
                alertsStatus.textContent = "Alerts on — keep this tab open to be notified.";
            } else {
                alertsStatus.textContent = "Notifications blocked — you'll still see on-page alerts while this tab is open.";
            }
        } else {
            alertsStatus.textContent = "Notifications aren't supported here — on-page alerts will still work.";
        }
        alertsEnabled = true;
        playBeep(); // confirms sound works, with the required user click
        enableBtn.disabled = true;
        enableBtn.textContent = "Alerts enabled";
    });
}

// ---- Poll for due reminders every 20 seconds, while this tab is open ----
function getNotifiedIds() {
    try {
        return JSON.parse(localStorage.getItem("gc_notified_reminders") || "[]");
    } catch (e) {
        return [];
    }
}
function markNotified(id) {
    const ids = getNotifiedIds();
    ids.push(id);
    localStorage.setItem("gc_notified_reminders", JSON.stringify(ids));
}

function checkDueReminders() {
    if (!alertsEnabled) return;
    const notified = getNotifiedIds();
    const now = new Date();

    document.querySelectorAll(".gc-reminder-item").forEach((item) => {
        const id = item.dataset.id;
        const timeStr = item.dataset.time;
        const title = item.dataset.title;
        if (!timeStr || notified.includes(id)) return;

        const due = new Date(timeStr);
        // Trigger once the due time has arrived (within the last 20s poll window)
        if (now >= due) {
            playBeep();
            showAlertBanner(title);
            if ("Notification" in window && Notification.permission === "granted") {
                new Notification("GramCare reminder", { body: title });
            }
            markNotified(id);
        }
    });
}

updateReminderBadges();
setInterval(() => {
    updateReminderBadges();
    checkDueReminders();
}, 20000);
