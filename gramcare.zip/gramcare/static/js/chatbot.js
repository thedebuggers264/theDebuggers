const chatWindow = document.getElementById("chatWindow");
const chatForm = document.getElementById("chatForm");
const messageInput = document.getElementById("messageInput");
const voiceBtn = document.getElementById("voiceBtn");
const voiceLang = document.getElementById("voiceLang");
const voiceStatus = document.getElementById("voiceStatus");

function addMessage(text, sender) {
    const div = document.createElement("div");
    div.className = "msg " + sender;
    div.textContent = text;
    chatWindow.appendChild(div);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}

chatForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const message = messageInput.value.trim();
    if (!message) return;

    addMessage(message, "user");
    messageInput.value = "";

    try {
        const res = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message }),
        });
        const data = await res.json();
        addMessage(data.reply, "bot");
    } catch (err) {
        addMessage("Sorry, something went wrong. Please try again.", "bot");
    }
});

// ---- Multilingual voice input using the browser's built-in Web Speech API ----
// Works in Chrome/Edge. Gracefully disables itself if unsupported.
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const LANG_LABELS = {
    "en-IN": "English",
    "hi-IN": "Hindi",
    "ta-IN": "Tamil",
};

if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.interimResults = false;

    voiceBtn.addEventListener("click", () => {
        recognition.lang = voiceLang.value; // language chosen by the user, read fresh each time
        recognition.start();
        voiceBtn.textContent = "🎙️...";
        voiceStatus.textContent = "Listening in " + LANG_LABELS[voiceLang.value] + "...";
    });

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        messageInput.value = transcript;
        voiceBtn.textContent = "🎤";
        voiceStatus.textContent = "Heard: \u201C" + transcript + "\u201D";
    };

    recognition.onerror = () => {
        voiceBtn.textContent = "🎤";
        voiceStatus.textContent = "Didn't catch that — please try again or type your question.";
    };

    recognition.onend = () => {
        voiceBtn.textContent = "🎤";
    };
} else {
    voiceBtn.disabled = true;
    voiceBtn.title = "Voice input not supported in this browser";
    voiceStatus.textContent = "Voice input isn't supported in this browser — try Chrome, or type your question.";
}
